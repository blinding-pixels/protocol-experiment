use std::collections::{BTreeMap, BTreeSet};

use crate::{
    CryptoError, SecretBytes32,
    key_schedule::derive_child_seed,
    tree_prf::{CapabilityId, SubtreeCapability, tree_capacity},
};

/// Local secret state for a segment-local point-puncturable PRF.
///
/// Public punctures form the replicated CRDT. This type intentionally exposes
/// no secret-state merge operation. Each replica applies the public puncture
/// set to its own local capability map.
pub struct PuncturablePrf {
    segment_id: [u8; 32],
    depth: u8,
    capabilities: BTreeMap<CapabilityId, SubtreeCapability>,
    public_punctures: BTreeSet<u64>,
}

impl PuncturablePrf {
    /// Initialize a full public-index namespace from one secret root.
    pub fn new(segment_id: [u8; 32], depth: u8, root: SecretBytes32) -> Result<Self, CryptoError> {
        let _ = tree_capacity(depth)?;
        let root_id = CapabilityId {
            prefix_len: 0,
            prefix: 0,
        };
        let root_capability = SubtreeCapability::new(segment_id, depth, root_id, root)?;
        let mut capabilities = BTreeMap::new();
        capabilities.insert(root_id, root_capability);

        Ok(Self {
            segment_id,
            depth,
            capabilities,
            public_punctures: BTreeSet::new(),
        })
    }

    /// Puncture one public message index.
    ///
    /// The selected capability, path direction, loop count, and resulting map
    /// keys depend only on public coordinates. Secret seed bytes are consumed
    /// only by fixed-layout HMAC calls.
    pub fn puncture(&mut self, index: u64) -> Result<(), CryptoError> {
        let capacity = tree_capacity(self.depth)?;
        if index >= capacity {
            return Err(CryptoError::InvalidPublicInput);
        }
        if self.public_punctures.contains(&index) {
            return Ok(());
        }

        let covering_id = self
            .capabilities
            .iter()
            .find(|(_, capability)| capability.covers(index))
            .map(|(id, _)| *id)
            .ok_or(CryptoError::NoCapability)?;

        let removed = self
            .capabilities
            .remove(&covering_id)
            .ok_or(CryptoError::NoCapability)?;
        let mut current = SecretBytes32::from_bytes(*removed.seed().expose());
        let mut node_prefix = covering_id.prefix;

        for level in covering_id.prefix_len..self.depth {
            let bit_position = self.depth - level - 1;
            let selected_bit = ((index >> bit_position) & 1) as u8;
            let sibling_bit = selected_bit ^ 1;

            let sibling_seed =
                derive_child_seed(&current, &self.segment_id, level, node_prefix, sibling_bit)?;
            let sibling_id = CapabilityId {
                prefix_len: level + 1,
                prefix: (node_prefix << 1) | u64::from(sibling_bit),
            };
            let sibling =
                SubtreeCapability::new(self.segment_id, self.depth, sibling_id, sibling_seed)?;
            if self.capabilities.insert(sibling_id, sibling).is_some() {
                return Err(CryptoError::InvalidPublicInput);
            }

            let next =
                derive_child_seed(&current, &self.segment_id, level, node_prefix, selected_bit)?;
            current = next;
            node_prefix = (node_prefix << 1) | u64::from(selected_bit);
        }

        // `current` is the punctured leaf seed. It is not inserted and is
        // wiped by `SecretBytes32` on drop. `removed` is also wiped on drop.
        self.public_punctures.insert(index);
        Ok(())
    }

    /// Apply an authenticated public puncture set to this local secret state.
    ///
    /// B-tree iteration order is public and deterministic. Correctness does not
    /// depend on this order: the capability representation is keyed by the
    /// canonical maximal public dyadic prefixes that remain.
    pub fn apply_public_punctures(&mut self, punctures: &BTreeSet<u64>) -> Result<(), CryptoError> {
        for index in punctures {
            self.puncture(*index)?;
        }
        Ok(())
    }

    /// Derive an unpunctured public point.
    pub fn evaluate(&self, index: u64) -> Result<SecretBytes32, CryptoError> {
        if self.public_punctures.contains(&index) {
            return Err(CryptoError::Punctured);
        }

        self.capabilities
            .values()
            .find(|capability| capability.covers(index))
            .ok_or(CryptoError::NoCapability)?
            .derive_leaf(index)
    }

    /// Authenticated public puncture facts already applied locally.
    #[must_use]
    pub const fn public_punctures(&self) -> &BTreeSet<u64> {
        &self.public_punctures
    }

    /// Public canonical capability-prefix identities.
    #[must_use]
    pub fn capability_ids(&self) -> Vec<CapabilityId> {
        self.capabilities.keys().copied().collect()
    }

    /// Public total tree depth.
    #[must_use]
    pub const fn depth(&self) -> u8 {
        self.depth
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use super::PuncturablePrf;
    use crate::{CryptoError, SecretBytes32, tree_capacity};

    fn build(order: &[u64]) -> Result<PuncturablePrf, CryptoError> {
        let mut state = PuncturablePrf::new([7_u8; 32], 5, SecretBytes32::from_bytes([11_u8; 32]))?;
        for index in order {
            state.puncture(*index)?;
        }
        Ok(state)
    }

    #[test]
    fn puncture_order_has_canonical_public_representation() -> Result<(), CryptoError> {
        let left = build(&[1, 7, 13, 29])?;
        let right = build(&[29, 13, 1, 7])?;

        assert_eq!(left.public_punctures(), right.public_punctures());
        assert_eq!(left.capability_ids(), right.capability_ids());

        let capacity = tree_capacity(left.depth())?;
        for index in 0..capacity {
            if left.public_punctures().contains(&index) {
                assert_eq!(left.evaluate(index).err(), Some(CryptoError::Punctured));
                assert_eq!(right.evaluate(index).err(), Some(CryptoError::Punctured));
            } else {
                let left_key = left.evaluate(index)?;
                let right_key = right.evaluate(index)?;
                assert!(bool::from(left_key.ct_eq(&right_key)));
            }
        }
        Ok(())
    }

    #[test]
    fn replay_uses_only_public_tombstones() -> Result<(), CryptoError> {
        let punctures = BTreeSet::from([0_u64, 2, 4, 8, 16]);
        let mut state = PuncturablePrf::new([3_u8; 32], 5, SecretBytes32::from_bytes([4_u8; 32]))?;
        state.apply_public_punctures(&punctures)?;
        assert_eq!(state.public_punctures(), &punctures);
        Ok(())
    }
}
