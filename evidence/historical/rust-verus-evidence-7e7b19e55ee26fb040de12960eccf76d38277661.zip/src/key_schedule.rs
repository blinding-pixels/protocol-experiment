use hmac::{Hmac, KeyInit, Mac};
use sha2::Sha256;

use crate::{CryptoError, SecretBytes32};

type HmacSha256 = Hmac<Sha256>;

const LIVE_DOMAIN: &[u8] = b"facets-cdg-v1/live-key";
const HISTORY_DOMAIN: &[u8] = b"facets-cdg-v1/history-root";
const TREE_DOMAIN: &[u8] = b"facets-cdg-v1/ggm-child";

fn finish_hmac(mac: HmacSha256) -> SecretBytes32 {
    let output = mac.finalize().into_bytes();
    let mut bytes = [0_u8; 32];
    bytes.copy_from_slice(&output);
    SecretBytes32::from_bytes(bytes)
}

fn keyed_hmac(secret: &SecretBytes32) -> Result<HmacSha256, CryptoError> {
    HmacSha256::new_from_slice(secret.expose()).map_err(|_| CryptoError::InvalidPublicInput)
}

/// Derive the live application key `L_v` from the internal `BeeKEM` node secret.
///
/// The HMAC input layout and length are fixed. `node_id` and `auth_digest` are
/// public transcript commitments.
pub fn derive_live_key(
    node_secret: &SecretBytes32,
    node_id: &[u8; 32],
    auth_digest: &[u8; 32],
) -> Result<SecretBytes32, CryptoError> {
    let mut mac = keyed_hmac(node_secret)?;
    mac.update(LIVE_DOMAIN);
    mac.update(node_id);
    mac.update(auth_digest);
    Ok(finish_hmac(mac))
}

/// Derive a segment-local retrospective-history root `R_s`.
///
/// The history label is distinct from the live-key label, preventing a history
/// capability from being interpreted as input to the live namespace.
pub fn derive_history_root(
    node_secret: &SecretBytes32,
    segment_id: &[u8; 32],
    auth_digest: &[u8; 32],
) -> Result<SecretBytes32, CryptoError> {
    let mut mac = keyed_hmac(node_secret)?;
    mac.update(HISTORY_DOMAIN);
    mac.update(segment_id);
    mac.update(auth_digest);
    Ok(finish_hmac(mac))
}

/// Derive one public-path GGM child seed.
///
/// `level`, `node_prefix`, and `child_bit` are public tree coordinates. The
/// secret seed is used only as the HMAC key and never controls project-owned
/// branching or memory access.
pub(crate) fn derive_child_seed(
    parent: &SecretBytes32,
    segment_id: &[u8; 32],
    level: u8,
    node_prefix: u64,
    child_bit: u8,
) -> Result<SecretBytes32, CryptoError> {
    if child_bit > 1 {
        return Err(CryptoError::InvalidPublicInput);
    }

    let mut mac = keyed_hmac(parent)?;
    mac.update(TREE_DOMAIN);
    mac.update(segment_id);
    mac.update(&[level]);
    mac.update(&node_prefix.to_be_bytes());
    mac.update(&[child_bit]);
    Ok(finish_hmac(mac))
}

#[cfg(test)]
mod tests {
    use super::{derive_history_root, derive_live_key};
    use crate::SecretBytes32;

    #[test]
    fn live_and_history_domains_are_distinct() -> Result<(), crate::CryptoError> {
        let root = SecretBytes32::from_bytes([7_u8; 32]);
        let public_id = [8_u8; 32];
        let auth = [9_u8; 32];

        let live = derive_live_key(&root, &public_id, &auth)?;
        let history = derive_history_root(&root, &public_id, &auth)?;
        assert!(!bool::from(live.ct_eq(&history)));
        Ok(())
    }
}
