use subtle::{Choice, ConstantTimeEq};
use zeroize::{Zeroize, ZeroizeOnDrop};

use crate::CryptoError;

/// Fixed-size secret material.
///
/// The type deliberately does not implement `Clone`, `Copy`, `Debug`,
/// serialization, or ordinary equality. Secret comparisons use
/// [`ConstantTimeEq`].
#[derive(Default, Zeroize, ZeroizeOnDrop)]
pub struct SecretBytes32([u8; 32]);

impl SecretBytes32 {
    /// Construct secret material from an owned fixed-size array.
    #[must_use]
    pub const fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }

    /// Fill a new secret from the operating-system random source.
    pub fn random() -> Result<Self, CryptoError> {
        let mut secret = Self([0_u8; 32]);
        getrandom::fill(&mut secret.0).map_err(|_| CryptoError::Randomness)?;
        Ok(secret)
    }

    /// Compare two fixed-size secrets without short-circuiting on the first
    /// unequal byte.
    #[must_use]
    pub fn ct_eq(&self, other: &Self) -> Choice {
        self.0.ct_eq(&other.0)
    }

    /// Replace this value in place after first wiping the previous bytes.
    ///
    /// This avoids reallocating a long-lived secret slot. The source remains
    /// owned by the caller and is not moved into the slot.
    pub(crate) fn overwrite_from(&mut self, source: &Self) {
        self.0.zeroize();
        self.0.copy_from_slice(&source.0);
    }

    /// Expose bytes only to the cryptographic primitive adapters in this
    /// package.
    pub(crate) const fn expose(&self) -> &[u8; 32] {
        &self.0
    }
}

/// Public identifier for a retained `BeeKEM` personal secret.
///
/// This identifier is signed, transcript-bound, and included in AEAD
/// associated data. It is public specifically so retained-secret selection
/// never requires trial decryption or a secret-dependent early exit.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct SecretId(pub [u8; 16]);

#[derive(Default)]
struct RetainedSlot {
    occupied: bool,
    id: SecretId,
    secret: SecretBytes32,
}

/// Fixed-capacity retained-secret store for finite `kappa` recovery.
///
/// Capacity, replacement position, occupancy, and identifiers are public.
/// Secret bytes never determine a branch, index, or loop bound. The backing
/// allocation is created once and never resized.
pub struct RetainedSecrets {
    slots: Box<[RetainedSlot]>,
    next_replacement: usize,
    occupied: usize,
}

impl RetainedSecrets {
    /// Allocate exactly `kappa` public slots.
    pub fn new(kappa: usize) -> Result<Self, CryptoError> {
        if kappa == 0 {
            return Err(CryptoError::InvalidCapacity);
        }

        let mut slots = Vec::with_capacity(kappa);
        slots.resize_with(kappa, RetainedSlot::default);

        Ok(Self {
            slots: slots.into_boxed_slice(),
            next_replacement: 0,
            occupied: 0,
        })
    }

    /// Insert or replace a secret under a public identifier.
    ///
    /// Re-inserting an existing identifier overwrites that public slot. A new
    /// identifier replaces the next public circular slot once `kappa` is full.
    pub fn insert(&mut self, id: SecretId, secret: &SecretBytes32) -> Result<(), CryptoError> {
        if let Some(slot) = self
            .slots
            .iter_mut()
            .find(|slot| slot.occupied && slot.id == id)
        {
            slot.secret.overwrite_from(secret);
            return Ok(());
        }

        let slot = self
            .slots
            .get_mut(self.next_replacement)
            .ok_or(CryptoError::InvalidCapacity)?;
        let was_occupied = slot.occupied;
        slot.secret.overwrite_from(secret);
        slot.id = id;
        slot.occupied = true;

        if !was_occupied {
            self.occupied += 1;
        }
        self.next_replacement = (self.next_replacement + 1) % self.slots.len();
        Ok(())
    }

    /// Select a retained secret by its public transcript-bound identifier.
    #[must_use]
    pub fn get(&self, id: SecretId) -> Option<&SecretBytes32> {
        self.slots
            .iter()
            .find(|slot| slot.occupied && slot.id == id)
            .map(|slot| &slot.secret)
    }

    /// Return the public identifiers currently present in slot order.
    #[must_use]
    pub fn public_ids(&self) -> Vec<SecretId> {
        self.slots
            .iter()
            .filter(|slot| slot.occupied)
            .map(|slot| slot.id)
            .collect()
    }

    /// Number of occupied public slots.
    #[must_use]
    pub const fn len(&self) -> usize {
        self.occupied
    }

    /// Whether no public slot is occupied.
    #[must_use]
    pub const fn is_empty(&self) -> bool {
        self.occupied == 0
    }

    /// Public configured finite-`kappa` capacity.
    #[must_use]
    pub fn capacity(&self) -> usize {
        self.slots.len()
    }
}

#[cfg(test)]
mod tests {
    use super::{RetainedSecrets, SecretBytes32, SecretId};

    #[test]
    fn retained_lookup_is_by_public_identifier() -> Result<(), crate::CryptoError> {
        let mut retained = RetainedSecrets::new(2)?;
        let first = SecretBytes32::from_bytes([1_u8; 32]);
        let second = SecretBytes32::from_bytes([2_u8; 32]);
        let first_id = SecretId([1_u8; 16]);
        let second_id = SecretId([2_u8; 16]);

        retained.insert(first_id, &first)?;
        retained.insert(second_id, &second)?;

        let recovered = retained
            .get(second_id)
            .ok_or(crate::CryptoError::UnknownSecretId)?;
        assert!(bool::from(recovered.ct_eq(&second)));
        assert_eq!(retained.public_ids(), vec![first_id, second_id]);
        Ok(())
    }

    #[test]
    fn circular_replacement_is_public_and_bounded() -> Result<(), crate::CryptoError> {
        let mut retained = RetainedSecrets::new(2)?;
        retained.insert(SecretId([1_u8; 16]), &SecretBytes32::from_bytes([1_u8; 32]))?;
        retained.insert(SecretId([2_u8; 16]), &SecretBytes32::from_bytes([2_u8; 32]))?;
        retained.insert(SecretId([3_u8; 16]), &SecretBytes32::from_bytes([3_u8; 32]))?;

        assert!(retained.get(SecretId([1_u8; 16])).is_none());
        assert!(retained.get(SecretId([2_u8; 16])).is_some());
        assert!(retained.get(SecretId([3_u8; 16])).is_some());
        assert_eq!(retained.len(), 2);
        Ok(())
    }
}
