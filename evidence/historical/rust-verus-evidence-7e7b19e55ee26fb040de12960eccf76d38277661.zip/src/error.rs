use core::fmt;

/// Errors intentionally avoid revealing which secret-dependent primitive check
/// failed. Public validation errors remain distinguishable.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CryptoError {
    /// The operating-system random source failed.
    Randomness,
    /// A public input has an invalid fixed length or range.
    InvalidPublicInput,
    /// X25519 produced a non-contributory shared secret.
    NonContributoryKeyAgreement,
    /// Signature verification failed.
    InvalidSignature,
    /// AEAD authentication or decryption failed.
    AuthenticationFailed,
    /// HPKE encapsulation, decapsulation, seal, or open failed.
    HpkeFailed,
    /// A public message index has been punctured.
    Punctured,
    /// No public capability prefix covers the requested public index.
    NoCapability,
    /// No retained secret is associated with the supplied public identifier.
    UnknownSecretId,
    /// The configured public capacity is zero or otherwise invalid.
    InvalidCapacity,
}

impl fmt::Display for CryptoError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        let message = match self {
            Self::Randomness => "operating-system randomness failed",
            Self::InvalidPublicInput => "invalid public input",
            Self::NonContributoryKeyAgreement => "non-contributory key agreement",
            Self::InvalidSignature => "signature verification failed",
            Self::AuthenticationFailed => "authentication failed",
            Self::HpkeFailed => "HPKE operation failed",
            Self::Punctured => "public index is punctured",
            Self::NoCapability => "no capability covers the public index",
            Self::UnknownSecretId => "unknown public retained-secret identifier",
            Self::InvalidCapacity => "invalid public capacity",
        };
        formatter.write_str(message)
    }
}

impl std::error::Error for CryptoError {}
