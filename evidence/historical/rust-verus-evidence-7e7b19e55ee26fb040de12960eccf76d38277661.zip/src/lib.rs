#![forbid(unsafe_code)]
#![deny(missing_docs)]

//! Memory-safe, constant-time-disciplined research implementation of the
//! secret-touching core required by the causal-DAG CGKA construction.
//!
//! This crate deliberately separates two kinds of code:
//!
//! - public authorization, causal-DAG, cover, and puncture schedules may branch
//!   on public data;
//! - private keys, node secrets, PRF seeds, content keys, plaintext, and
//!   authentication outputs are passed only to selected cryptographic
//!   primitives and never choose project-owned branches, indices, or loop
//!   bounds.
//!
//! The crate is a research artifact, not a production-ready implementation of
//! the complete `BeeKEM` protocol. The puncturable/constrained PRF construction
//! and `BeeKEM` orchestration remain novel code requiring independent
//! cryptographic and side-channel review.

mod error;
mod key_schedule;
mod primitives;
mod puncturable;
mod secret;
mod tree_prf;

pub use error::CryptoError;
pub use key_schedule::{derive_history_root, derive_live_key};
pub use primitives::{
    AeadEnvelope, AeadKey, GrantEnvelope, GrantRecipientKey, NikeSecret, OperationSigningKey,
    ct_equal_32, seal_grant, verify_operation_signature,
};
pub use puncturable::PuncturablePrf;
pub use secret::{RetainedSecrets, SecretBytes32, SecretId};
pub use tree_prf::{
    CapabilityId, MAX_TREE_DEPTH, SubtreeCapability, cover_prefix, derive_from_cover,
    derive_subtree_seed, encode_cover, tree_capacity,
};
