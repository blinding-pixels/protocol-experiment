use zeroize::Zeroizing;

use crate::{CryptoError, SecretBytes32, key_schedule::derive_child_seed};

const CAPABILITY_RECORD_SIZE: usize = 32 + 1 + 1 + 8 + 32;

/// Maximum depth representable by the public `u64` message-index namespace.
pub const MAX_TREE_DEPTH: u8 = 63;

/// Public identity of one dyadic subtree.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct CapabilityId {
    /// Number of public path bits consumed from the root.
    pub prefix_len: u8,
    /// The public path bits, stored in the low `prefix_len` bits.
    pub prefix: u64,
}

/// One segment-tagged constrained PRF capability.
///
/// Secret bytes live behind a stable heap pointer so sorting and moving public
/// metadata does not copy the seed itself.
pub struct SubtreeCapability {
    segment_id: [u8; 32],
    depth: u8,
    id: CapabilityId,
    seed: Box<SecretBytes32>,
}

impl SubtreeCapability {
    /// Construct a capability after validating public coordinates.
    pub fn new(
        segment_id: [u8; 32],
        depth: u8,
        id: CapabilityId,
        seed: SecretBytes32,
    ) -> Result<Self, CryptoError> {
        validate_coordinates(depth, id)?;
        Ok(Self {
            segment_id,
            depth,
            id,
            seed: Box::new(seed),
        })
    }

    /// Public segment tag.
    #[must_use]
    pub const fn segment_id(&self) -> &[u8; 32] {
        &self.segment_id
    }

    /// Public total tree depth.
    #[must_use]
    pub const fn depth(&self) -> u8 {
        self.depth
    }

    /// Public subtree identity.
    #[must_use]
    pub const fn id(&self) -> CapabilityId {
        self.id
    }

    /// Whether this public subtree covers a public message index.
    #[must_use]
    pub fn covers(&self, index: u64) -> bool {
        if !index_in_tree(self.depth, index) {
            return false;
        }
        if self.id.prefix_len == 0 {
            return true;
        }

        let suffix_len = self.depth - self.id.prefix_len;
        index >> suffix_len == self.id.prefix
    }

    /// Derive a leaf key for a covered public index.
    pub fn derive_leaf(&self, index: u64) -> Result<SecretBytes32, CryptoError> {
        if !self.covers(index) {
            return Err(CryptoError::NoCapability);
        }

        let mut current = SecretBytes32::from_bytes(*self.seed.expose());
        let mut node_prefix = self.id.prefix;

        for level in self.id.prefix_len..self.depth {
            let bit_position = self.depth - level - 1;
            let child_bit = ((index >> bit_position) & 1) as u8;
            let next =
                derive_child_seed(&current, &self.segment_id, level, node_prefix, child_bit)?;
            current = next;
            node_prefix = (node_prefix << 1) | u64::from(child_bit);
        }

        Ok(current)
    }

    pub(crate) fn seed(&self) -> &SecretBytes32 {
        &self.seed
    }
}

/// Public capacity of a depth-`depth` segment tree.
pub fn tree_capacity(depth: u8) -> Result<u64, CryptoError> {
    if depth > MAX_TREE_DEPTH {
        return Err(CryptoError::InvalidPublicInput);
    }
    Ok(1_u64 << depth)
}

fn index_in_tree(depth: u8, index: u64) -> bool {
    tree_capacity(depth).is_ok_and(|capacity| index < capacity)
}

fn validate_coordinates(depth: u8, id: CapabilityId) -> Result<(), CryptoError> {
    let _ = tree_capacity(depth)?;
    if id.prefix_len > depth {
        return Err(CryptoError::InvalidPublicInput);
    }
    if id.prefix_len == 0 {
        return if id.prefix == 0 {
            Ok(())
        } else {
            Err(CryptoError::InvalidPublicInput)
        };
    }

    let prefix_capacity = 1_u64 << id.prefix_len;
    if id.prefix >= prefix_capacity {
        return Err(CryptoError::InvalidPublicInput);
    }
    Ok(())
}

/// Derive the seed at a public subtree coordinate from a segment root.
pub fn derive_subtree_seed(
    root: &SecretBytes32,
    segment_id: &[u8; 32],
    id: CapabilityId,
) -> Result<SecretBytes32, CryptoError> {
    if id.prefix_len > MAX_TREE_DEPTH {
        return Err(CryptoError::InvalidPublicInput);
    }
    if id.prefix_len == 0 && id.prefix != 0 {
        return Err(CryptoError::InvalidPublicInput);
    }
    if id.prefix_len > 0 && id.prefix >= (1_u64 << id.prefix_len) {
        return Err(CryptoError::InvalidPublicInput);
    }

    let mut current = SecretBytes32::from_bytes(*root.expose());
    let mut node_prefix = 0_u64;

    for level in 0..id.prefix_len {
        let bit_position = id.prefix_len - level - 1;
        let child_bit = ((id.prefix >> bit_position) & 1) as u8;
        let next = derive_child_seed(&current, segment_id, level, node_prefix, child_bit)?;
        current = next;
        node_prefix = (node_prefix << 1) | u64::from(child_bit);
    }

    Ok(current)
}

/// Build the exact canonical dyadic cover of the public prefix
/// `[0, end_exclusive)`.
///
/// All branch decisions and loop counts depend only on public `depth` and
/// `end_exclusive`. At most `depth + 1` boxed secret seeds are emitted.
pub fn cover_prefix(
    root: &SecretBytes32,
    segment_id: [u8; 32],
    depth: u8,
    end_exclusive: u64,
) -> Result<Vec<SubtreeCapability>, CryptoError> {
    let capacity = tree_capacity(depth)?;
    if end_exclusive > capacity {
        return Err(CryptoError::InvalidPublicInput);
    }

    let mut cover = Vec::with_capacity(end_exclusive.count_ones() as usize);
    let mut start = 0_u64;

    for block_power in (0..=depth).rev() {
        let block_size = 1_u64 << block_power;
        if end_exclusive & block_size == 0 {
            continue;
        }

        let prefix_len = depth - block_power;
        let prefix = start >> block_power;
        let id = CapabilityId { prefix_len, prefix };
        let seed = derive_subtree_seed(root, &segment_id, id)?;
        cover.push(SubtreeCapability::new(segment_id, depth, id, seed)?);
        start += block_size;
    }

    debug_assert_eq!(start, end_exclusive);
    Ok(cover)
}

/// Derive a leaf from the unique public capability that covers it.
pub fn derive_from_cover(
    cover: &[SubtreeCapability],
    index: u64,
) -> Result<SecretBytes32, CryptoError> {
    cover
        .iter()
        .find(|capability| capability.covers(index))
        .ok_or(CryptoError::NoCapability)?
        .derive_leaf(index)
}

/// Serialize public capability coordinates and secret seeds into a zeroizing
/// transport buffer.
///
/// The buffer is allocated once at its exact public size, preventing
/// secret-bearing reallocation. The result must be immediately passed to the
/// authenticated grant-transport primitive.
pub fn encode_cover(cover: &[SubtreeCapability]) -> Result<Zeroizing<Vec<u8>>, CryptoError> {
    let count = u32::try_from(cover.len()).map_err(|_| CryptoError::InvalidPublicInput)?;
    let payload_len = 4_usize
        .checked_add(
            cover
                .len()
                .checked_mul(CAPABILITY_RECORD_SIZE)
                .ok_or(CryptoError::InvalidPublicInput)?,
        )
        .ok_or(CryptoError::InvalidPublicInput)?;

    let mut encoded = Zeroizing::new(Vec::with_capacity(payload_len));
    encoded.extend_from_slice(&count.to_be_bytes());

    for capability in cover {
        encoded.extend_from_slice(&capability.segment_id);
        encoded.push(capability.depth);
        encoded.push(capability.id.prefix_len);
        encoded.extend_from_slice(&capability.id.prefix.to_be_bytes());
        encoded.extend_from_slice(capability.seed.expose());
    }

    Ok(encoded)
}

#[cfg(test)]
mod tests {
    use super::{cover_prefix, derive_from_cover, tree_capacity};
    use crate::SecretBytes32;

    #[test]
    fn every_prefix_cover_is_exact_through_depth_eight() -> Result<(), crate::CryptoError> {
        let root = SecretBytes32::from_bytes([42_u8; 32]);
        let segment = [9_u8; 32];

        for depth in 0..=8 {
            let capacity = tree_capacity(depth)?;
            for end in 0..=capacity {
                let cover = cover_prefix(&root, segment, depth, end)?;
                assert!(cover.len() <= usize::from(depth) + 1);
                for index in 0..capacity {
                    let covered = cover
                        .iter()
                        .filter(|capability| capability.covers(index))
                        .count();
                    assert_eq!(covered, usize::from(index < end));
                }
            }
        }
        Ok(())
    }

    #[test]
    fn constrained_leaf_matches_full_tree_leaf() -> Result<(), crate::CryptoError> {
        let root = SecretBytes32::from_bytes([3_u8; 32]);
        let segment = [4_u8; 32];
        let cover = cover_prefix(&root, segment, 6, 45)?;
        let constrained = derive_from_cover(&cover, 31)?;
        let full_cover = cover_prefix(&root, segment, 6, 64)?;
        let full = derive_from_cover(&full_cover, 31)?;
        assert!(bool::from(constrained.ct_eq(&full)));
        Ok(())
    }
}
