use chacha20poly1305::{
    XChaCha20Poly1305, XNonce,
    aead::{Aead, KeyInit, Payload},
};
use ed25519_dalek::{Signature, Signer, SigningKey, VerifyingKey};
use hkdf::Hkdf;
use hpke::{
    Deserializable, Kem as KemTrait, OpModeR, OpModeS, Serializable,
    aead::ChaCha20Poly1305 as HpkeChaCha20Poly1305, kdf::HkdfSha256, kem::X25519HkdfSha256,
};
use sha2::Sha256;
use subtle::{Choice, ConstantTimeEq};
use x25519_dalek::{PublicKey as X25519PublicKey, StaticSecret};
use zeroize::{Zeroize, Zeroizing};

use crate::{CryptoError, SecretBytes32};

const NIKE_SALT: &[u8] = b"facets-cdg-v1/x25519-root";

type GrantKem = X25519HkdfSha256;
type GrantKdf = HkdfSha256;
type GrantAead = HpkeChaCha20Poly1305;

/// Ed25519 signing key kept in the dalek zeroize-on-drop type.
pub struct OperationSigningKey(SigningKey);

impl OperationSigningKey {
    /// Generate a signing key from 32 bytes obtained from the operating-system
    /// CSPRNG. The temporary seed is wiped on drop.
    pub fn generate() -> Result<Self, CryptoError> {
        let seed = SecretBytes32::random()?;
        Ok(Self(SigningKey::from_bytes(seed.expose())))
    }

    /// Public verification key bytes.
    #[must_use]
    pub fn verifying_key(&self) -> [u8; 32] {
        self.0.verifying_key().to_bytes()
    }

    /// Sign the complete canonical operation transcript.
    #[must_use]
    pub fn sign(&self, transcript: &[u8]) -> [u8; 64] {
        self.0.sign(transcript).to_bytes()
    }
}

/// Strictly verify an Ed25519 signature over a public canonical transcript.
pub fn verify_operation_signature(
    verification_key: &[u8; 32],
    transcript: &[u8],
    signature: &[u8; 64],
) -> Result<(), CryptoError> {
    let key =
        VerifyingKey::from_bytes(verification_key).map_err(|_| CryptoError::InvalidSignature)?;
    let signature = Signature::from_bytes(signature);
    key.verify_strict(transcript, &signature)
        .map_err(|_| CryptoError::InvalidSignature)
}

/// Long-lived X25519 personal secret used as the concrete NIKE building block.
pub struct NikeSecret(StaticSecret);

impl NikeSecret {
    /// Generate a fresh static secret from the fallible operating-system random
    /// source and wipe the temporary seed after importing it.
    pub fn generate() -> Result<Self, CryptoError> {
        let mut seed = [0_u8; 32];
        getrandom::fill(&mut seed).map_err(|_| CryptoError::Randomness)?;
        let secret = StaticSecret::from(seed);
        seed.zeroize();
        Ok(Self(secret))
    }

    /// Public X25519 key bytes.
    #[must_use]
    pub fn public_key(&self) -> [u8; 32] {
        X25519PublicKey::from(&self.0).to_bytes()
    }

    /// Compute a contributory X25519 shared secret and expand it into a
    /// context-bound internal node secret.
    pub fn agree(
        &self,
        peer_public_key: &[u8; 32],
        public_context: &[u8],
    ) -> Result<SecretBytes32, CryptoError> {
        let peer = X25519PublicKey::from(*peer_public_key);
        let shared = self.0.diffie_hellman(&peer);
        if !shared.was_contributory() {
            return Err(CryptoError::NonContributoryKeyAgreement);
        }

        let hkdf = Hkdf::<Sha256>::new(Some(NIKE_SALT), shared.as_bytes());
        let mut output = [0_u8; 32];
        hkdf.expand(public_context, &mut output)
            .map_err(|_| CryptoError::InvalidPublicInput)?;
        Ok(SecretBytes32::from_bytes(output))
    }
}

/// `XChaCha20-Poly1305` key for node-secret and application-content envelopes.
pub struct AeadKey(SecretBytes32);

impl AeadKey {
    /// Generate a fresh 256-bit key.
    pub fn random() -> Result<Self, CryptoError> {
        Ok(Self(SecretBytes32::random()?))
    }

    /// Wrap an already-derived key.
    #[must_use]
    pub const fn from_secret(secret: SecretBytes32) -> Self {
        Self(secret)
    }

    /// Encrypt with a fresh public 192-bit nonce and public associated data.
    pub fn seal(&self, plaintext: &[u8], aad: &[u8]) -> Result<AeadEnvelope, CryptoError> {
        let cipher = XChaCha20Poly1305::new_from_slice(self.0.expose())
            .map_err(|_| CryptoError::InvalidPublicInput)?;
        let mut nonce_bytes = [0_u8; 24];
        getrandom::fill(&mut nonce_bytes).map_err(|_| CryptoError::Randomness)?;
        let nonce = XNonce::from(nonce_bytes);
        let ciphertext = cipher
            .encrypt(
                &nonce,
                Payload {
                    msg: plaintext,
                    aad,
                },
            )
            .map_err(|_| CryptoError::AuthenticationFailed)?;
        Ok(AeadEnvelope {
            nonce: nonce_bytes,
            ciphertext,
        })
    }

    /// Authenticate and decrypt one envelope. All failures are mapped to one
    /// opaque authentication error. Successful plaintext is returned in a
    /// zeroizing buffer.
    pub fn open(
        &self,
        envelope: &AeadEnvelope,
        aad: &[u8],
    ) -> Result<Zeroizing<Vec<u8>>, CryptoError> {
        let cipher = XChaCha20Poly1305::new_from_slice(self.0.expose())
            .map_err(|_| CryptoError::InvalidPublicInput)?;
        let nonce = XNonce::from(envelope.nonce);
        let plaintext = cipher
            .decrypt(
                &nonce,
                Payload {
                    msg: &envelope.ciphertext,
                    aad,
                },
            )
            .map_err(|_| CryptoError::AuthenticationFailed)?;
        Ok(Zeroizing::new(plaintext))
    }
}

/// Public nonce plus authenticated ciphertext.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AeadEnvelope {
    /// Public `XChaCha20` nonce.
    pub nonce: [u8; 24],
    /// Ciphertext including the authentication tag.
    pub ciphertext: Vec<u8>,
}

/// HPKE recipient keypair stored as a zeroizing serialized private key and a
/// public serialized key.
///
/// The wrapper avoids keeping a long-lived opaque HPKE private-key object whose
/// erasure behavior is not part of this package's type contract.
pub struct GrantRecipientKey {
    private_key: SecretBytes32,
    public_key: [u8; 32],
}

impl GrantRecipientKey {
    /// Generate 256 bits of input keying material and use RFC 9180 deterministic
    /// key derivation for the selected X25519 KEM.
    pub fn generate() -> Result<Self, CryptoError> {
        let mut input_key_material = [0_u8; 32];
        getrandom::fill(&mut input_key_material).map_err(|_| CryptoError::Randomness)?;
        let (private_key, public_key) = GrantKem::derive_keypair(&input_key_material);
        input_key_material.zeroize();

        let private_bytes = private_key.to_bytes();
        let public_bytes = public_key.to_bytes();
        if private_bytes.as_slice().len() != 32 || public_bytes.as_slice().len() != 32 {
            return Err(CryptoError::InvalidPublicInput);
        }

        let mut private = [0_u8; 32];
        private.copy_from_slice(private_bytes.as_slice());
        let mut public = [0_u8; 32];
        public.copy_from_slice(public_bytes.as_slice());

        Ok(Self {
            private_key: SecretBytes32::from_bytes(private),
            public_key: public,
        })
    }

    /// Public RFC 9180 recipient key bytes.
    #[must_use]
    pub const fn public_key(&self) -> [u8; 32] {
        self.public_key
    }

    /// Decapsulate and authenticate one single-shot retrospective grant.
    /// Successful capability plaintext is returned in a zeroizing buffer.
    pub fn open(
        &self,
        envelope: &GrantEnvelope,
        info: &[u8],
        aad: &[u8],
    ) -> Result<Zeroizing<Vec<u8>>, CryptoError> {
        let private_key = <<GrantKem as KemTrait>::PrivateKey as Deserializable>::from_bytes(
            self.private_key.expose(),
        )
        .map_err(|_| CryptoError::HpkeFailed)?;
        let encapped_key = <<GrantKem as KemTrait>::EncappedKey as Deserializable>::from_bytes(
            &envelope.encapped_key,
        )
        .map_err(|_| CryptoError::HpkeFailed)?;

        let plaintext = hpke::single_shot_open::<GrantAead, GrantKdf, GrantKem>(
            &OpModeR::Base,
            &private_key,
            &encapped_key,
            info,
            &envelope.ciphertext,
            aad,
        )
        .map_err(|_| CryptoError::HpkeFailed)?;
        Ok(Zeroizing::new(plaintext))
    }
}

/// Seal one retrospective grant to a serialized public recipient key.
///
/// The function uses only RFC 9180 Base mode with the fixed suite
/// X25519/HKDF-SHA-256/ChaCha20-Poly1305. The HPKE `danger` API is not exposed.
pub fn seal_grant(
    recipient_public_key: &[u8; 32],
    plaintext: &[u8],
    info: &[u8],
    aad: &[u8],
) -> Result<GrantEnvelope, CryptoError> {
    let public_key =
        <<GrantKem as KemTrait>::PublicKey as Deserializable>::from_bytes(recipient_public_key)
            .map_err(|_| CryptoError::HpkeFailed)?;

    let (encapped_key, ciphertext) = hpke::single_shot_seal::<GrantAead, GrantKdf, GrantKem>(
        &OpModeS::Base,
        &public_key,
        info,
        plaintext,
        aad,
    )
    .map_err(|_| CryptoError::HpkeFailed)?;
    let serialized = encapped_key.to_bytes();

    Ok(GrantEnvelope {
        encapped_key: serialized.as_slice().to_vec(),
        ciphertext,
    })
}

/// Public HPKE encapsulated key plus authenticated ciphertext.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct GrantEnvelope {
    /// Serialized public encapsulated KEM key.
    pub encapped_key: Vec<u8>,
    /// Authenticated grant ciphertext.
    pub ciphertext: Vec<u8>,
}

/// Constant-time comparison for fixed-size secret commitments.
#[must_use]
pub fn ct_equal_32(left: &[u8; 32], right: &[u8; 32]) -> Choice {
    left.ct_eq(right)
}

#[cfg(test)]
mod tests {
    use super::{
        AeadKey, GrantRecipientKey, NikeSecret, OperationSigningKey, ct_equal_32, seal_grant,
        verify_operation_signature,
    };

    #[test]
    fn signing_and_strict_verification_round_trip() -> Result<(), crate::CryptoError> {
        let signing_key = OperationSigningKey::generate()?;
        let message = b"canonical public operation transcript";
        let signature = signing_key.sign(message);
        verify_operation_signature(&signing_key.verifying_key(), message, &signature)
    }

    #[test]
    fn nike_agreement_is_context_bound() -> Result<(), crate::CryptoError> {
        let alice = NikeSecret::generate()?;
        let bob = NikeSecret::generate()?;
        let context = b"public node and authorization digest";
        let alice_root = alice.agree(&bob.public_key(), context)?;
        let bob_root = bob.agree(&alice.public_key(), context)?;
        assert!(bool::from(alice_root.ct_eq(&bob_root)));
        Ok(())
    }

    #[test]
    fn nike_rejects_noncontributory_public_key() -> Result<(), crate::CryptoError> {
        let secret = NikeSecret::generate()?;
        let result = secret.agree(&[0_u8; 32], b"public context");
        assert_eq!(
            result.err(),
            Some(crate::CryptoError::NonContributoryKeyAgreement)
        );
        Ok(())
    }

    #[test]
    fn xchacha_round_trip() -> Result<(), crate::CryptoError> {
        let key = AeadKey::random()?;
        let aad = b"public transcript";
        let envelope = key.seal(b"secret node payload", aad)?;
        let plaintext = key.open(&envelope, aad)?;
        assert_eq!(plaintext.as_slice(), b"secret node payload");
        Ok(())
    }

    #[test]
    fn hpke_grant_round_trip() -> Result<(), crate::CryptoError> {
        let recipient = GrantRecipientKey::generate()?;
        let info = b"facets retrospective grant v1";
        let aad = b"public recipient merge and region digest";
        let envelope = seal_grant(
            &recipient.public_key(),
            b"secret constrained capability payload",
            info,
            aad,
        )?;
        let plaintext = recipient.open(&envelope, info, aad)?;
        assert_eq!(
            plaintext.as_slice(),
            b"secret constrained capability payload"
        );
        Ok(())
    }

    #[test]
    fn fixed_secret_comparison_does_not_short_circuit() {
        assert!(bool::from(ct_equal_32(&[7_u8; 32], &[7_u8; 32])));
        assert!(!bool::from(ct_equal_32(&[7_u8; 32], &[8_u8; 32])));
    }
}
