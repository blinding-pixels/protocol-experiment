#![allow(unused_imports)]

use vstd::prelude::*;

fn main() {}

verus! {

/// Abstract labels for every operation in the implementation that touches
/// secret key material.
pub enum SecretOperationKind {
    GenerateSigningKey,
    SignTranscript,
    GenerateNikeSecret,
    DeriveNikePublicKey,
    NikeAgreement,
    HkdfExpand,
    AeadSeal,
    AeadOpen,
    DeriveLiveKey,
    DeriveHistoryRoot,
    DeriveTreeChild,
    DeriveTreeLeaf,
    BuildConstrainedCover,
    HpkeSeal,
    HpkeOpen,
    PprfPuncture,
    PprfEvaluate,
    CompareSecret,
    EraseSecret,
}

/// Operations whose secret arithmetic is delegated to a selected primitive.
pub open spec fn delegated_to_standard_primitive(op: SecretOperationKind) -> bool {
    match op {
        SecretOperationKind::GenerateSigningKey => true,
        SecretOperationKind::SignTranscript => true,
        SecretOperationKind::GenerateNikeSecret => true,
        SecretOperationKind::DeriveNikePublicKey => true,
        SecretOperationKind::NikeAgreement => true,
        SecretOperationKind::HkdfExpand => true,
        SecretOperationKind::AeadSeal => true,
        SecretOperationKind::AeadOpen => true,
        SecretOperationKind::DeriveLiveKey => true,
        SecretOperationKind::DeriveHistoryRoot => true,
        SecretOperationKind::HpkeSeal => true,
        SecretOperationKind::HpkeOpen => true,
        SecretOperationKind::CompareSecret => true,
        SecretOperationKind::EraseSecret => true,
        _ => false,
    }
}

/// Operations whose schedule is project-owned novel PRF/PPRF code.
pub open spec fn novel_public_schedule(op: SecretOperationKind) -> bool {
    match op {
        SecretOperationKind::DeriveTreeChild => true,
        SecretOperationKind::DeriveTreeLeaf => true,
        SecretOperationKind::BuildConstrainedCover => true,
        SecretOperationKind::PprfPuncture => true,
        SecretOperationKind::PprfEvaluate => true,
        _ => false,
    }
}

/// The inventory is exhaustive: every secret-touching operation is assigned to
/// exactly the standard-primitive or novel-public-schedule boundary.
pub proof fn every_secret_operation_is_classified(op: SecretOperationKind)
    ensures
        delegated_to_standard_primitive(op) || novel_public_schedule(op),
        !(delegated_to_standard_primitive(op) && novel_public_schedule(op)),
{
}

/// Runtime loop-count model for deriving a leaf below a public subtree prefix.
/// The arguments are public tree coordinates.
pub fn tree_traversal_iterations(depth: usize, prefix_len: usize) -> (steps: usize)
    requires
        prefix_len <= depth,
    ensures
        steps == depth - prefix_len,
{
    let mut level = prefix_len;
    let mut steps = 0usize;

    while level < depth
        invariant
            prefix_len <= level,
            level <= depth,
            steps == level - prefix_len,
        decreases depth - level,
    {
        level = level + 1;
        steps = steps + 1;
    }

    steps
}

/// A compatibility retained-secret scan, when needed, must execute exactly the
/// configured public `kappa` iterations and may not stop at the successful
/// decryption. The preferred implementation instead performs public-ID lookup.
pub fn compatibility_scan_iterations(kappa: usize) -> (steps: usize)
    ensures
        steps == kappa,
{
    let mut steps = 0usize;

    while steps < kappa
        invariant
            steps <= kappa,
        decreases kappa - steps,
    {
        steps = steps + 1;
    }

    steps
}

/// Replay count is exactly the number of authenticated public puncture facts.
pub fn puncture_replay_iterations(public_puncture_count: usize) -> (steps: usize)
    ensures
        steps == public_puncture_count,
{
    let mut steps = 0usize;

    while steps < public_puncture_count
        invariant
            steps <= public_puncture_count,
        decreases public_puncture_count - steps,
    {
        steps = steps + 1;
    }

    steps
}

/// Mathematical power of two used only to describe a public path bit.
pub open spec fn pow2(exponent: nat) -> nat
    decreases exponent,
{
    if exponent == 0 {
        1
    } else {
        2 * pow2((exponent - 1) as nat)
    }
}

/// One GGM path decision. `secret_seed` is deliberately present in the
/// signature but absent from the body: the selected child is a bit of the
/// public message index, never a bit of the secret seed.
pub open spec fn public_child_bit(
    public_index: nat,
    public_bit_position: nat,
    secret_seed: int,
) -> nat {
    (public_index / pow2(public_bit_position)) % 2
}

pub proof fn child_choice_is_secret_independent(
    public_index: nat,
    public_bit_position: nat,
    secret_seed_one: int,
    secret_seed_two: int,
)
    ensures
        public_child_bit(public_index, public_bit_position, secret_seed_one)
            == public_child_bit(public_index, public_bit_position, secret_seed_two),
{
}

/// Lookup trace for finite-`kappa` recovery. The public identifiers and public
/// target determine which comparisons occur. Secret slot contents are not an
/// input to the trace.
pub open spec fn retained_lookup_trace(
    public_ids: Seq<int>,
    public_target_id: int,
    secret_slot_contents: Seq<int>,
) -> Seq<int> {
    public_ids
}

pub proof fn retained_lookup_is_secret_independent(
    public_ids: Seq<int>,
    public_target_id: int,
    secret_slots_one: Seq<int>,
    secret_slots_two: Seq<int>,
)
    ensures
        retained_lookup_trace(public_ids, public_target_id, secret_slots_one)
            =~= retained_lookup_trace(public_ids, public_target_id, secret_slots_two),
{
}

/// Public puncture replay supplies the complete transition schedule. Secret
/// capability bytes do not change the list of points or its order.
pub open spec fn puncture_replay_trace(
    public_punctures: Seq<nat>,
    secret_capability_state: Seq<int>,
) -> Seq<nat> {
    public_punctures
}

pub proof fn puncture_replay_is_secret_independent(
    public_punctures: Seq<nat>,
    secret_state_one: Seq<int>,
    secret_state_two: Seq<int>,
)
    ensures
        puncture_replay_trace(public_punctures, secret_state_one)
            =~= puncture_replay_trace(public_punctures, secret_state_two),
{
}

/// Secret capability states expose local derive, puncture, and erase
/// transitions only. There is intentionally no secret-state merge constructor;
/// merge occurs solely over the public puncture sequence above.
pub enum LocalSecretTransition {
    Derive,
    Puncture,
    Erase,
}

pub open spec fn is_local_only_transition(transition: LocalSecretTransition) -> bool {
    match transition {
        LocalSecretTransition::Derive => true,
        LocalSecretTransition::Puncture => true,
        LocalSecretTransition::Erase => true,
    }
}

pub proof fn every_secret_transition_is_local(transition: LocalSecretTransition)
    ensures is_local_only_transition(transition),
{
}

} // verus!
